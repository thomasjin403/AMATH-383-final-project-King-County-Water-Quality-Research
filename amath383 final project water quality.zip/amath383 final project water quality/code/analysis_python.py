"""
AMATH 383 Final Project: King County Stream Water Quality Dynamics
Reproducible Python analysis for data cleaning, visualization, model fitting,
parameter uncertainty, phase plots, and bifurcation analysis.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import minimize
from statsmodels.stats.diagnostic import acorr_ljungbox

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "King_County_Streams_Water_Quality_Index.csv"
FIG = ROOT / "figures"
TAB = ROOT / "tables"
SITE = "3106"
SPLIT_DATE = "2016-01-01"
FIG.mkdir(exist_ok=True)
TAB.mkdir(exist_ok=True)


def norm_month(x):
    if pd.isna(x):
        return np.nan
    s = str(x).strip()
    if s.lower() == "wholeyear":
        return np.nan
    try:
        return int(float(s))
    except Exception:
        return np.nan


def wateryear_to_calendar(wy, month):
    return wy - 1 if int(month) >= 10 else wy


def load_data(path=DATA):
    df = pd.read_csv(path, low_memory=False)
    df["MonthNum"] = df["Month"].apply(norm_month)
    df["CalYear"] = df.apply(
        lambda r: wateryear_to_calendar(int(r["WaterYear"]), int(r["MonthNum"]))
        if pd.notna(r["MonthNum"]) else np.nan,
        axis=1,
    )
    df["CalDate"] = pd.to_datetime(
        dict(year=df["CalYear"].fillna(2000).astype(int),
             month=df["MonthNum"].fillna(1).astype(int),
             day=1),
        errors="coerce")
    return df


def choose_site(df):
    ms = df[df["ParameterGroup"].eq("MonthlyScore") & df["MonthNum"].notna()].copy()
    summary = ms.groupby(["Locator", "SiteName", "StreamName"]).agg(
        n=("WQI", "count"), first=("CalDate", "min"), last=("CalDate", "max"), mean=("WQI", "mean")
    ).reset_index().sort_values("n", ascending=False)
    summary.to_csv(TAB / "site_record_summary.csv", index=False)
    return summary


def build_site_series(df, locator=SITE, end_date="2025-12-01"):
    ms = df[(df["Locator"].astype(str).eq(str(locator))) &
            (df["ParameterGroup"].eq("MonthlyScore")) &
            (df["CalDate"].notna())].copy()
    ms = ms.sort_values("CalDate")
    ms = ms[ms["CalDate"] <= pd.Timestamp(end_date)]
    full = pd.DataFrame({"CalDate": pd.date_range(ms["CalDate"].min(), ms["CalDate"].max(), freq="MS")})
    full = full.merge(ms[["CalDate", "WQI", "SiteName", "StreamName"]], on="CalDate", how="left")
    full["WQI_interp"] = full["WQI"].interpolate(method="linear").ffill().bfill()
    full["x"] = full["WQI_interp"] / 100.0
    full["month"] = full["CalDate"].dt.month
    full["t"] = np.arange(len(full))
    return full


def build_transitions(site):
    tr = pd.DataFrame({
        "date": site["CalDate"].iloc[1:].values,
        "x_prev": site["x"].iloc[:-1].values,
        "x_next": site["x"].iloc[1:].values,
        "wqi_prev": site["WQI_interp"].iloc[:-1].values,
        "wqi_next": site["WQI_interp"].iloc[1:].values,
        "month_next": site["month"].iloc[1:].values,
        "t": np.arange(len(site)-1) + 1,
    })
    tr["sin"] = np.sin(2*np.pi*tr["t"]/12)
    tr["cos"] = np.cos(2*np.pi*tr["t"]/12)
    return tr


def pred_climatology(params, d):
    return np.asarray(params)[d["month_next"].values - 1]


def pred_linear(params, d):
    a0, b1, s, c = params
    y = a0 + b1*d["x_prev"].values + s*d["sin"].values + c*d["cos"].values
    return np.clip(y, 0, 1)


def pred_logistic(params, d):
    a, K, s, c = params
    x = d["x_prev"].values
    y = x + a*x*(1 - x/K) + s*d["sin"].values + c*d["cos"].values
    return np.clip(y, 0, 1)


def pred_ricker(params, d):
    r, K, s, c = params
    x = d["x_prev"].values
    y = x*np.exp(r*(1 - x/K) + s*d["sin"].values + c*d["cos"].values)
    return np.clip(y, 1e-8, 1.0)


def pred_ricker_trend(params, d):
    r, K, s, c, trend = params
    x = d["x_prev"].values
    tcenter = (d["t"].values - d["t"].values.mean()) / 120.0
    y = x*np.exp(r*(1 - x/K) + s*d["sin"].values + c*d["cos"].values + trend*tcenter)
    return np.clip(y, 1e-8, 1.0)

MODELS = {
    "Monthly climatology baseline": pred_climatology,
    "Linear recovery + seasonality": pred_linear,
    "Logistic recovery + seasonality": pred_logistic,
    "Ricker recovery + seasonality": pred_ricker,
    "Ricker recovery + seasonality + trend": pred_ricker_trend,
}


def init_and_bounds(name, d):
    if name == "Monthly climatology baseline":
        x0 = np.array([d.loc[d["month_next"] == m, "x_next"].mean() for m in range(1, 13)])
        x0 = np.nan_to_num(x0, nan=d["x_next"].mean())
        bounds = [(0, 1)] * 12
    elif name == "Linear recovery + seasonality":
        X = np.column_stack([np.ones(len(d)), d["x_prev"].values, d["sin"].values, d["cos"].values])
        x0 = np.linalg.lstsq(X, d["x_next"].values, rcond=None)[0]
        bounds = [(-1, 1), (-1, 2), (-1, 1), (-1, 1)]
    elif name == "Logistic recovery + seasonality":
        x0 = np.array([0.2, 0.8, -0.03, 0.0])
        bounds = [(-2, 2), (0.2, 2.0), (-1, 1), (-1, 1)]
    elif name == "Ricker recovery + seasonality":
        x0 = np.array([0.2, 0.8, -0.03, 0.0])
        bounds = [(-3, 3), (0.2, 2.0), (-1, 1), (-1, 1)]
    else:
        x0 = np.array([0.2, 0.8, -0.03, 0.0, 0.0])
        bounds = [(-3, 3), (0.2, 2.0), (-1, 1), (-1, 1), (-2, 2)]
    return x0, bounds


def fit_model(d, name):
    f = MODELS[name]
    x0, bounds = init_and_bounds(name, d)
    y = d["x_next"].values

    def obj(par):
        yhat = f(par, d)
        return np.sum((y - yhat)**2)

    res = minimize(obj, x0, method="L-BFGS-B", bounds=bounds)
    par = res.x
    yhat = f(par, d)
    resid = y - yhat
    n = len(resid)
    k = len(par) + 1  # parameters plus residual sigma
    rss = np.sum(resid**2)
    sigma2 = rss / n
    ll = -0.5*n*(np.log(2*np.pi*sigma2) + 1)
    return {"name": name, "params": par, "pred": yhat, "resid": resid,
            "rmse": np.sqrt(np.mean(resid**2)), "mae": np.mean(np.abs(resid)),
            "aic": 2*k - 2*ll, "bic": k*np.log(n) - 2*ll, "sigma": np.sqrt(sigma2)}


def metrics(y, yhat):
    resid = y - yhat
    rss = np.sum(resid**2)
    ss_tot = np.sum((y - y.mean())**2)
    return {"rmse": np.sqrt(np.mean(resid**2)), "mae": np.mean(np.abs(resid)), "r2": 1-rss/ss_tot}


def block_bootstrap_logistic(train, fit, n_boot=250, block=12, seed=383):
    rng = np.random.default_rng(seed)
    base_pred = pred_logistic(fit["params"], train)
    resid = train["x_next"].values - base_pred
    out = []
    for _ in range(n_boot):
        idx = []
        while len(idx) < len(resid):
            st = rng.integers(0, len(resid)-block+1)
            idx.extend(range(st, st+block))
        yb = np.clip(base_pred + resid[idx[:len(resid)]], 0, 1)
        tmp = train.copy()
        tmp["x_next"] = yb
        out.append(fit_model(tmp, "Logistic recovery + seasonality")["params"])
    boot = pd.DataFrame(out, columns=["a", "K", "s", "c"])
    boot.to_csv(TAB / "bootstrap_logistic_params.csv", index=False)
    return boot


def metropolis_hastings(train, fit, boot, n_iter=20000, burn=5000, thin=5, seed=383):
    rng = np.random.default_rng(seed)
    cov4 = np.cov(boot.values.T)
    cov = np.zeros((5,5))
    cov[:4,:4] = cov4
    cov[4,4] = 0.05**2
    cov *= 0.4
    L = np.linalg.cholesky(cov + 1e-10*np.eye(5))
    y = train["x_next"].values

    def log_prior(theta):
        a, K, s, c, log_sigma = theta
        sigma = np.exp(log_sigma)
        if not (-2 < a < 2 and 0.2 < K < 2 and -1 < s < 1 and -1 < c < 1 and 0.001 < sigma < 1):
            return -np.inf
        return -0.5*(s/0.2)**2 - 0.5*(c/0.2)**2 - 0.5*((log_sigma+2.0)/1.0)**2

    def log_lik(theta):
        a, K, s, c, log_sigma = theta
        sigma = np.exp(log_sigma)
        mu = pred_logistic(np.array([a, K, s, c]), train)
        return -0.5*np.sum(((y-mu)/sigma)**2 + np.log(2*np.pi*sigma**2))

    theta = np.r_[fit["params"], np.log(fit["sigma"])]
    lp = log_prior(theta) + log_lik(theta)
    samples = []
    accepted = 0
    for i in range(n_iter):
        prop = theta + L @ rng.normal(size=5)
        lp_prop = log_prior(prop) + log_lik(prop)
        if np.log(rng.uniform()) < lp_prop - lp:
            theta, lp = prop, lp_prop
            accepted += 1
        if i >= burn and (i-burn) % thin == 0:
            samples.append(theta.copy())
    post = pd.DataFrame(samples, columns=["a", "K", "s", "c", "log_sigma"])
    post["sigma"] = np.exp(post["log_sigma"])
    post.attrs["acceptance_rate"] = accepted / n_iter
    post.to_csv(TAB / "posterior_logistic_params.csv", index=False)
    return post


def save_latex_table(df, path, caption="", label=""):
    with open(path, "w", encoding="utf-8") as f:
        f.write(df.to_latex(index=False, escape=False, float_format="%.3f", caption=caption, label=label))


def plot_map(df):
    annual = df[(df["ParameterGroup"].eq("AnnualScore")) &
                (df["Month"].astype(str).str.lower().eq("wholeyear")) &
                (df["WaterYear"].eq(2025))].drop_duplicates("Locator")
    fig, ax = plt.subplots(figsize=(7.2,5.6))
    sc = ax.scatter(annual["lng"], annual["lat"], c=annual["WQI"], s=45, alpha=0.9)
    sel = annual[annual["Locator"].astype(str).eq(SITE)]
    if len(sel):
        ax.scatter(sel["lng"], sel["lat"], s=150, facecolors="none", edgecolors="black", linewidths=1.8, label="Focal site 3106")
        ax.legend(frameon=False)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("King County 2025 annual WQI by monitoring site")
    fig.colorbar(sc, ax=ax, label="Annual WQI")
    fig.tight_layout()
    fig.savefig(FIG / "fig_map_2025_wqi.png", dpi=200)
    plt.close(fig)


def plot_climatology(df):
    s = df[(df["Locator"].astype(str).eq(SITE)) &
           (df["ParameterGroup"].isin(["MonthlyScore", "Temperature", "DissolvedOxygen", "Nutrient", "Sediment", "FecalBacteria"])) &
           (df["MonthNum"].notna())].copy()
    clim = s.groupby(["ParameterGroup", "MonthNum"])["WQI"].mean().unstack(0)
    fig, ax = plt.subplots(figsize=(8,4.8))
    for col in ["MonthlyScore", "Temperature", "DissolvedOxygen", "Nutrient", "Sediment", "FecalBacteria"]:
        if col in clim.columns:
            ax.plot(clim.index, clim[col], marker="o", linewidth=1.8, label=col)
    ax.set_xticks(range(1,13))
    ax.set_xlabel("Calendar month")
    ax.set_ylabel("Mean WQI or WQI subscore")
    ax.set_ylim(0, 100)
    ax.set_title("Seasonal climatology at Green River at Starfire Way (site 3106)")
    ax.legend(frameon=False, fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(FIG / "fig_climatology_components.png", dpi=200)
    plt.close(fig)
    clim.to_csv(TAB / "site3106_monthly_climatology.csv")


def simulate_logistic(site, params):
    a, K, s, c = params
    x = [site["x"].iloc[0]]
    for i in range(1, len(site)):
        xn = x[-1] + a*x[-1]*(1 - x[-1]/K) + s*np.sin(2*np.pi*i/12) + c*np.cos(2*np.pi*i/12)
        x.append(float(np.clip(xn, 0, 1)))
    return np.array(x)


def plot_time_series(site, params):
    sim = 100 * simulate_logistic(site, params)
    fig, ax = plt.subplots(figsize=(9,4.6))
    ax.plot(site["CalDate"], site["WQI_interp"], label="Observed/interpolated monthly WQI", linewidth=1.1)
    ax.plot(site["CalDate"], sim, label="Free-running logistic seasonal simulation", linewidth=1.7)
    ax.axvline(pd.Timestamp(SPLIT_DATE), linestyle="--", linewidth=1, label="Train/test split")
    ax.set_ylim(0,100)
    ax.set_xlabel("Date")
    ax.set_ylabel("WQI")
    ax.set_title("Monthly WQI and fitted nonlinear seasonal model")
    ax.legend(frameon=False, fontsize=8, loc="lower left")
    fig.tight_layout()
    fig.savefig(FIG / "fig_timeseries_logistic_fit.png", dpi=200)
    plt.close(fig)


def plot_one_step(site, tr, train, test, params):
    all_pred = pred_logistic(params, tr) * 100
    fig, ax = plt.subplots(figsize=(9,4.6))
    ax.plot(tr["date"], tr["wqi_next"], label="Observed monthly WQI", linewidth=1.1)
    ax.plot(tr["date"], all_pred, label="One-step fitted model", linewidth=1.7)
    ax.axvline(pd.Timestamp(SPLIT_DATE), linestyle="--", linewidth=1)
    ax.set_ylim(0,100)
    ax.set_xlabel("Date")
    ax.set_ylabel("WQI")
    ax.set_title("One-step prediction of monthly WQI")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "fig_onestep_logistic_prediction.png", dpi=200)
    plt.close(fig)


def plot_phase(train, params):
    a, K, s, c = params
    fig, ax = plt.subplots(figsize=(6,6))
    ax.scatter(train["x_prev"].values*100, train["x_next"].values*100, s=13, alpha=0.4, label="Observed transitions")
    ax.plot([0,100], [0,100], linestyle="--", linewidth=1.2, label="Identity line")
    xg = np.linspace(0,1,250)
    for m in [1,4,8,11]:
        yg = xg + a*xg*(1-xg/K) + s*np.sin(2*np.pi*m/12) + c*np.cos(2*np.pi*m/12)
        ax.plot(100*xg, 100*np.clip(yg, 0, 1), linewidth=1.4, label=f"Map, month {m}")
    ax.set_xlim(0,100); ax.set_ylim(0,100)
    ax.set_xlabel(r"$W_t$")
    ax.set_ylabel(r"$W_{t+1}$")
    ax.set_title("Phase plot of fitted seasonal logistic map")
    ax.legend(frameon=False, fontsize=7, loc="upper left")
    fig.tight_layout()
    fig.savefig(FIG / "fig_phase_plot.png", dpi=200)
    plt.close(fig)


def plot_bifurcation(ricker_params):
    r_fit, K, *_ = ricker_params
    rs = np.linspace(0, 3.2, 550)
    R, X = [], []
    for r in rs:
        x = 0.35
        for i in range(700):
            x = x*np.exp(r*(1 - x/K))
            x = float(np.clip(x, 1e-8, 2.0))
            if i >= 550:
                R.append(r); X.append(100*x)
    fig, ax = plt.subplots(figsize=(8,4.8))
    ax.plot(R, X, ",", alpha=0.35)
    ax.axvline(r_fit, linestyle="--", linewidth=1.4, label=fr"Fitted $r\approx {r_fit:.2f}$")
    ax.axvline(2.0, linestyle=":", linewidth=1.4, label="First period-doubling threshold r=2")
    ax.set_ylim(0, 100)
    ax.set_xlabel("Ricker growth parameter r")
    ax.set_ylabel("Long-run WQI")
    ax.set_title("Bifurcation diagram for the unforced Ricker map")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "fig_bifurcation_ricker.png", dpi=200)
    plt.close(fig)


def plot_posteriors(post):
    cols = ["a", "K", "s", "c", "sigma"]
    for col in cols:
        fig, ax = plt.subplots(figsize=(5.5,3.5))
        ax.hist(post[col].values, bins=40)
        ax.set_title(f"Posterior samples for {col}")
        ax.set_xlabel(col)
        ax.set_ylabel("Frequency")
        fig.tight_layout()
        fig.savefig(FIG / f"fig_posterior_{col}.png", dpi=200)
        plt.close(fig)


def main():
    df = load_data()
    site_summary = choose_site(df)
    site = build_site_series(df)
    tr = build_transitions(site)
    train = tr[tr["date"] < pd.Timestamp(SPLIT_DATE)].copy()
    test = tr[tr["date"] >= pd.Timestamp(SPLIT_DATE)].copy()
    fits = {name: fit_model(train, name) for name in MODELS}

    rows = []
    for name, fit in fits.items():
        yhat_test = MODELS[name](fit["params"], test)
        mt = metrics(test["x_next"].values, yhat_test)
        rows.append({
            "Model": name,
            "Parameters": len(fit["params"]),
            "Train RMSE": 100*fit["rmse"],
            "Test RMSE": 100*mt["rmse"],
            "Train MAE": 100*fit["mae"],
            "Test MAE": 100*mt["mae"],
            "AIC": fit["aic"],
            "BIC": fit["bic"],
            "Test R2": mt["r2"],
        })
    comp = pd.DataFrame(rows).sort_values("Test RMSE")
    comp.to_csv(TAB / "model_comparison.csv", index=False)
    save_latex_table(comp.round(3), TAB / "model_comparison.tex", caption="Model comparison for site 3106.", label="tab:model_comparison")

    logfit = fits["Logistic recovery + seasonality"]
    boot = block_bootstrap_logistic(train, logfit)
    post = metropolis_hastings(train, logfit, boot)

    ci_boot = boot.quantile([0.025, 0.975]).T
    ci_post = post[["a", "K", "s", "c", "sigma"]].quantile([0.025, 0.975]).T
    param = pd.DataFrame({
        "Parameter": ["a", "K", "s", "c", "sigma"],
        "Point estimate": list(logfit["params"]) + [logfit["sigma"]],
        "Bootstrap 2.5%": [ci_boot.loc[x, 0.025] if x in ci_boot.index else np.nan for x in ["a", "K", "s", "c", "sigma"]],
        "Bootstrap 97.5%": [ci_boot.loc[x, 0.975] if x in ci_boot.index else np.nan for x in ["a", "K", "s", "c", "sigma"]],
        "Posterior 2.5%": [ci_post.loc[x, 0.025] for x in ["a", "K", "s", "c", "sigma"]],
        "Posterior 97.5%": [ci_post.loc[x, 0.975] for x in ["a", "K", "s", "c", "sigma"]],
    })
    param.to_csv(TAB / "logistic_parameter_estimates.csv", index=False)
    save_latex_table(param.round(3), TAB / "logistic_parameter_estimates.tex", caption="Parameter estimates for the seasonal logistic model.", label="tab:params")

    lb = acorr_ljungbox(logfit["resid"], lags=[12], return_df=True)
    lb.to_csv(TAB / "ljung_box_logistic.csv")

    amp = np.sqrt(logfit["params"][2]**2 + logfit["params"][3]**2) * 100
    summary = {
        "site": SITE,
        "selected_site_name": site_summary[site_summary["Locator"].astype(str).eq(SITE)]["SiteName"].iloc[0],
        "selected_stream": site_summary[site_summary["Locator"].astype(str).eq(SITE)]["StreamName"].iloc[0],
        "n_months": len(site),
        "train_start": str(train["date"].min().date()),
        "train_end": str(train["date"].max().date()),
        "test_start": str(test["date"].min().date()),
        "test_end": str(test["date"].max().date()),
        "logistic_a": logfit["params"][0],
        "logistic_K": logfit["params"][1],
        "equilibrium_wqi": 100*logfit["params"][1],
        "seasonal_amplitude_wqi": amp,
        "ricker_r": fits["Ricker recovery + seasonality"]["params"][0],
        "ljung_box_p_lag12": float(lb["lb_pvalue"].iloc[0]),
    }
    pd.Series(summary).to_csv(TAB / "key_results.csv")

    plot_map(df)
    plot_climatology(df)
    plot_time_series(site, logfit["params"])
    plot_one_step(site, tr, train, test, logfit["params"])
    plot_phase(train, logfit["params"])
    plot_bifurcation(fits["Ricker recovery + seasonality"]["params"])
    plot_posteriors(post)
    print("Analysis complete. Key results:")
    print(pd.Series(summary))
    print(comp)

if __name__ == "__main__":
    main()
