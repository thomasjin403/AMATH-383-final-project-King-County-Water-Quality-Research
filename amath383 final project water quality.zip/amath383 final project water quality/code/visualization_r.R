# AMATH 383 Final Project R visualization helper
# This script reproduces several visualizations using tidyverse/ggplot2.
# It is optional because the main modeling workflow is in Python.

library(tidyverse)

ROOT <- normalizePath(file.path(dirname(sys.frame(1)$ofile), ".."), mustWork = FALSE)
DATA <- file.path(ROOT, "data", "King_County_Streams_Water_Quality_Index.csv")
FIG <- file.path(ROOT, "figures")
dir.create(FIG, showWarnings = FALSE, recursive = TRUE)

norm_month <- function(x) {
  x <- as.character(x)
  suppressWarnings(as.integer(ifelse(tolower(x) == "wholeyear", NA, x)))
}

df <- read_csv(DATA, show_col_types = FALSE) |>
  mutate(
    MonthNum = norm_month(Month),
    CalYear = if_else(!is.na(MonthNum) & MonthNum >= 10, WaterYear - 1L, WaterYear),
    CalDate = as.Date(sprintf("%04d-%02d-01", CalYear, replace_na(MonthNum, 1L)))
  )

# 1. Annual spatial distribution for the most recent full water year in the file.
annual <- df |>
  filter(ParameterGroup == "AnnualScore", tolower(Month) == "wholeyear", WaterYear == max(WaterYear, na.rm = TRUE)) |>
  distinct(Locator, .keep_all = TRUE)

p_map <- ggplot(annual, aes(x = lng, y = lat, color = WQI)) +
  geom_point(size = 2.4, alpha = 0.9) +
  geom_point(data = filter(annual, Locator == "3106"), shape = 21, color = "black", fill = NA, size = 5, stroke = 1.2) +
  labs(title = "King County annual WQI by monitoring site",
       subtitle = paste("WaterYear", max(annual$WaterYear, na.rm = TRUE)),
       x = "Longitude", y = "Latitude", color = "Annual WQI") +
  theme_minimal(base_size = 11)

ggsave(file.path(FIG, "r_fig_map_annual_wqi.png"), p_map, width = 7, height = 5, dpi = 200)

# 2. Component climatology at focal site 3106.
component_order <- c("MonthlyScore", "Temperature", "DissolvedOxygen", "Nutrient", "Sediment", "FecalBacteria")
clim <- df |>
  filter(Locator == "3106", ParameterGroup %in% component_order, !is.na(MonthNum)) |>
  group_by(ParameterGroup, MonthNum) |>
  summarize(mean_score = mean(WQI, na.rm = TRUE), .groups = "drop") |>
  mutate(ParameterGroup = factor(ParameterGroup, levels = component_order))

p_clim <- ggplot(clim, aes(x = MonthNum, y = mean_score, group = ParameterGroup, color = ParameterGroup)) +
  geom_line(linewidth = 0.9) +
  geom_point(size = 1.8) +
  scale_x_continuous(breaks = 1:12) +
  coord_cartesian(ylim = c(0, 100)) +
  labs(title = "Seasonal WQI and subscore climatology at site 3106",
       x = "Calendar month", y = "Mean WQI or subscore", color = "Parameter group") +
  theme_minimal(base_size = 11) +
  theme(legend.position = "bottom")

ggsave(file.path(FIG, "r_fig_climatology_components.png"), p_clim, width = 8, height = 5, dpi = 200)

# 3. Distribution of monthly WQI by month.
monthly <- df |>
  filter(Locator == "3106", ParameterGroup == "MonthlyScore", !is.na(MonthNum))

p_box <- ggplot(monthly, aes(x = factor(MonthNum), y = WQI)) +
  geom_boxplot(outlier.alpha = 0.4) +
  labs(title = "Monthly WQI distribution at site 3106",
       x = "Calendar month", y = "Monthly WQI") +
  theme_minimal(base_size = 11)

ggsave(file.path(FIG, "r_fig_monthly_boxplot.png"), p_box, width = 7, height = 4.5, dpi = 200)

message("R visualizations saved in: ", FIG)
